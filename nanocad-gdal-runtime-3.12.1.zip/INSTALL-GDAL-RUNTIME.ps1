$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$sync = Join-Path $env:LOCALAPPDATA 'ASDC\LoadFile\NANOCAD'
New-Item -ItemType Directory -Path $sync -Force | Out-Null
$gdalSrc = Join-Path $src 'installer\gdal'
$toolSrc = Join-Path $src 'installer\tools\NcGdalGeo'
if (-not (Test-Path (Join-Path $gdalSrc 'x64\gdal_wrap.dll'))) { throw 'installer\gdal missing' }
if (-not (Test-Path (Join-Path $toolSrc 'NcGdalGeo.exe'))) { throw 'NcGdalGeo missing' }
$gdalDest = Join-Path $sync 'gdal'
$toolDest = Join-Path $sync 'tools\NcGdalGeo'
if (Test-Path $gdalDest) { Remove-Item $gdalDest -Recurse -Force }
if (Test-Path $toolDest) { Remove-Item $toolDest -Recurse -Force }
New-Item -ItemType Directory -Path $gdalDest -Force | Out-Null
New-Item -ItemType Directory -Path $toolDest -Force | Out-Null
Copy-Item (Join-Path $gdalSrc '*') $gdalDest -Recurse -Force
Copy-Item (Join-Path $toolSrc '*') $toolDest -Recurse -Force
Write-Host "GDAL runtime installed to $sync"
