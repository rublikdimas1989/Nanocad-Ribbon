nanocad-gdal-runtime-3.12.1
Matched GDAL / GDAL.Native / GDAL.Plugins 3.12.1 + NcGdalGeo (geo + TIF translate).

Install once (nanoCAD closed):
  INSTALL-GDAL-RUNTIME.bat

Leaves:
  %LOCALAPPDATA%\ASDC\LoadFile\NANOCAD\gdal\
  %LOCALAPPDATA%\ASDC\LoadFile\NANOCAD\tools\NcGdalGeo\

Slim plugin zips (v1.2.49+) reuse this automatically.
