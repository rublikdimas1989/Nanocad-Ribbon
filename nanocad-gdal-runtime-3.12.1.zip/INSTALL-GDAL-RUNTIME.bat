@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL-GDAL-RUNTIME.ps1"
if errorlevel 1 pause
