using System.Reflection;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("NcBootstrap")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.2.81.0")]
[assembly: AssemblyInformationalVersion("1.2.81+RibbonPanels")]
[assembly: AssemblyProduct("NcBootstrap")]
[assembly: AssemblyTitle("NcBootstrap")]
[assembly: TargetPlatform("Windows7.0")]
[assembly: SupportedOSPlatform("Windows7.0")]
[assembly: AssemblyVersion("1.0.0.0")]
